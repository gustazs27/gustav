
function calcularIMC(){

let peso = document.getElementById("peso").value;
let altura = document.getElementById("altura").value;

if(!peso || !altura){
document.getElementById("resultado").innerHTML = "Preencha peso e altura.";
return;
}

let imc = peso / (altura * altura);
let classificacao = "";

if(imc < 18.5){
classificacao = "Abaixo do peso";
}
else if(imc < 25){
classificacao = "Peso normal";
}
else if(imc < 30){
classificacao = "Sobrepeso";
}
else{
classificacao = "Obesidade";
}

document.getElementById("resultado").innerHTML =
"Seu IMC é " + imc.toFixed(2) + " (" + classificacao + ")";
}